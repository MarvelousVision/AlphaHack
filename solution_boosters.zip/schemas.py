from typing import Any, Literal
from pydantic import BaseModel, Field, ConfigDict, model_validator

PARAM_RANGES = {
    "dtr": {"max_depth": (3, 30), "min_samples_leaf": (1, 20)},
    "dtc": {"max_depth": (3, 30), "min_samples_leaf": (1, 20)},

    "rfr": {
        "n_estimators": (100, 500),
        "max_depth": (5, 30),
        "min_samples_leaf": (1, 10),
    },
    "rfc": {
        "n_estimators": (100, 500),
        "max_depth": (5, 30),
        "min_samples_leaf": (1, 10),
    },

    "svr": {"C": (0.01, 100), "epsilon": (0.01, 1)},
    "svc": {"C": (0.01, 100)},

    "lvr": {"C": (0.01, 100), "epsilon": (0, 0.5)},
    "lvc": {"C": (0.01, 100)},

    "lbr": {
        "num_leaves": (15, 127),
        "max_depth": (3, 12),
        "learning_rate": (0.01, 0.2),
        "n_estimators": (200, 1500),
        "min_child_samples": (10, 100),
        "reg_lambda": (0, 10),
    },
    "lbc": {
        "num_leaves": (15, 127),
        "max_depth": (3, 12),
        "learning_rate": (0.01, 0.2),
        "n_estimators": (200, 1500),
        "min_child_samples": (10, 100),
        "reg_lambda": (0, 10),
    },

    "xbr": {
        "max_depth": (3, 10),
        "learning_rate": (0.01, 0.2),
        "n_estimators": (200, 1200),
        "subsample": (0.6, 1.0),
        "colsample_bytree": (0.6, 1.0),
        "reg_lambda": (0, 10),
    },
    "xbc": {
        "max_depth": (3, 10),
        "learning_rate": (0.01, 0.2),
        "n_estimators": (200, 1200),
        "subsample": (0.6, 1.0),
        "colsample_bytree": (0.6, 1.0),
        "reg_lambda": (0, 10),
    },
    "cbr": {
        "iterations": (100, 2000),
        "depth": (2, 10),
        "learning_rate": (0.01, 0.3),
        "l2_leaf_reg": (1, 20),
        "random_seed": (0, 2147483647),
    },
    "cbc": {
        "iterations": (100, 2000),
        "depth": (2, 10),
        "learning_rate": (0.01, 0.3),
        "l2_leaf_reg": (1, 20),
        "random_seed": (0, 2147483647),
    },
}

INT_PARAMS = {
    "max_depth", "min_samples_leaf", "n_estimators",
    "num_leaves", "min_child_samples",
    "iterations", "depth", "random_seed",
}

class SearchParam(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["int", "float"]
    low: float
    high: float
    log: bool = False

    @model_validator(mode="after")
    def check_range(self):
        if not self.low < self.high:
            raise ValueError("low must be less than high")

        if self.log and self.low <= 0:
            raise ValueError("log scale requires low > 0")

        if self.type == "int":
            if not self.low.is_integer() or not self.high.is_integer():
                raise ValueError("Integer bounds must be whole numbers")
        return self
class ModelConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: Literal[
    "cbr", "cbc", "lnr",
    "dtr", "dtc",
    "rfr", "rfc",
    "svr", "svc",
    "lvr", "lvc",
    "lbr", "lbc",
    "xbr", "xbc"
    ]
    hyperparameters: dict[str, Any] = Field(default_factory=dict)
    @model_validator(mode="after")
    def validate_hyperparameters(self):
        params = self.hyperparameters
        allowed = PARAM_RANGES.get(self.name, {})
       
        for key, value in params.items():
            if self.name in ("svc", "svr") and key == "gamma":
                if value not in ("scale", "auto"):
                    raise ValueError("gamma must be scale or auto")
                continue
            if self.name in ("cbr", "cbc") and key == "verbose":
                if type(value) is not bool:
                    raise ValueError("verbose must be boolean")
                continue
            if key not in allowed:
                raise ValueError(
                    f"{key} is not allowed for {self.name}"
                )

            if value is None and key == "max_depth" and self.name in ("rfr", "rfc"):
                continue

            low, high = allowed[key]

            if key in INT_PARAMS:
                if type(value) is not int:
                    raise ValueError(f"{key} must be an integer")
            elif type(value) not in (int, float):
                raise ValueError(f"{key} must be numeric")

            if not low <= value <= high:
                raise ValueError(
                    f"{key} must be between {low} and {high}"
                )

        return self
class SearchConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: ModelConfig.model_fields["name"].annotation
    search_space: dict[str, SearchParam]

    @model_validator(mode="after")
    def validate_search_space(self):
        allowed = PARAM_RANGES.get(self.name, {})

        if not self.search_space:
            raise ValueError("search_space cannot be empty")

        for key, spec in self.search_space.items():
            if key not in allowed:
                raise ValueError(
                    f"{key} is not allowed for {self.name}"
                )

            min_allowed, max_allowed = allowed[key]
            if not (
                min_allowed <= spec.low < spec.high <= max_allowed
            ):
                raise ValueError(
                    f"{key} outside allowed range"
                )
            expected_type = (
                "int" if key in INT_PARAMS else "float"
            )
            if spec.type != expected_type:
                raise ValueError(
                    f"{key} must use {expected_type}"
                )
        return self
class PreprocessingConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    missing_values: Literal["native", "median", "mean", "most_frequent"]
    categorical_encoding: Literal[ "native", "onehot", "ordinal"]
    scaling: Literal["none", "standard", "robust"]


class FeatureConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    strategy: Literal["baseline"] = "baseline"
    drop_columns: list[str] = Field(default_factory=list)


class ExperimentPlan(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: Literal["run_experiment"]
    hypothesis: str = Field(min_length=1)

    model: ModelConfig
    features: FeatureConfig

    reasoning: str = Field(min_length=1)
    estimated_time_sec: int = Field(gt=0, le=10800)
class OptunaExperimentPlan(BaseModel):
    model_config = ConfigDict(extra="forbid")

    action: Literal["run_optuna"]
    hypothesis: str = Field(min_length=1)
    model: SearchConfig
    reasoning: str = Field(min_length=1)
    estimated_time_sec: int = Field(gt=0, le=10800)
    drop_columns: list[str] = Field(default_factory=list)

class MetricResult(BaseModel):
    name: str
    value: float
    direction: Literal["maximize", "minimize"]


class TrialResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    score: float = Field(allow_inf_nan=False)
    params: dict[str, Any]


class ExperimentResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    experiment_id: str
    status: Literal["success", "failed"]
    model_name: str

    metric: MetricResult | None = None
    cv_std: float | None = Field(default=None, ge=0, allow_inf_nan=False)
    duration_sec: float = Field(ge=0)

    best_params: dict[str, Any] = Field(default_factory=dict)
    completed_trials: int = Field(default=0, ge=0)
    top_trials: list[TrialResult] = Field(default_factory=list)

    error: str | None = None